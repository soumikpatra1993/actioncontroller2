class LoginController < ApplicationController
  def users
    session[:admin] = @user.id
  end
