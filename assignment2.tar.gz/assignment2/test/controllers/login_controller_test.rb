require 'test_helper'

class LoginControllerTest < ActionDispatch::IntegrationTest
  test "should get users" do
    get login_users_url
    assert_response :success
  end

end
